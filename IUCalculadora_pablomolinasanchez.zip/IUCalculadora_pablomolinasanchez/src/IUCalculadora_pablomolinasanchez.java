import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class IUCalculadora_pablomolinasanchez {

	private JFrame frame;
	private JTextField textField;
	private double a=0;
	private double b=0;
	private double c=0;
	private boolean haceOperacion=false;
	private String operacion;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IUCalculadora_pablomolinasanchez window = new IUCalculadora_pablomolinasanchez();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public IUCalculadora_pablomolinasanchez() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 271, 340);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(21, 11, 218, 23);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton bSeven = new JButton("7");
		bSeven.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bSeven.setBounds(21, 88, 50, 31);
		frame.getContentPane().add(bSeven);
		bSeven.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bSeven.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bSeven.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bSeven.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bSeven.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			});
		
		JButton bFour = new JButton("4");
		bFour.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bFour.setBounds(21, 134, 50, 31);
		frame.getContentPane().add(bFour);
		bFour.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bFour.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") &&  c>0) {
						String number=textField.getText()+bFour.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bFour.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bFour.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			});
		
		JButton bFive = new JButton("5");
		bFive.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bFive.setBounds(78, 134, 50, 31);
		frame.getContentPane().add(bFive);
		bFive.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bFive.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bFive.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bFive.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bFive.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			
			
			});
		
		JButton bEigth = new JButton("8");
		bEigth.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bEigth.setBounds(78, 88, 50, 31);
		frame.getContentPane().add(bEigth);
		bEigth.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bEigth.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bEigth.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bEigth.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bEigth.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			}
			);
		
		JButton bNine = new JButton("9");
		bNine.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bNine.setBounds(132, 88, 50, 31);
		frame.getContentPane().add(bNine);
		bNine.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bNine.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bNine.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bNine.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bNine.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			
			}
			});
		
		JButton bSix = new JButton("6");
		bSix.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bSix.setBounds(132, 134, 50, 31);
		frame.getContentPane().add(bSix);
		bSix.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e) {
			if(operacion!=null) {
				String number=textField.getText()+bSix.getText();
				textField.setText(number);
				b=Double.parseDouble(number);
			}if(haceOperacion){
				if(textField.getText().contains("-") && c>0) {
					String number=textField.getText()+bSix.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
					haceOperacion=false;
				}else {
					textField.setText(null);
					String number=textField.getText()+bSix.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
					haceOperacion=false;
				}	
			
			}else if(operacion==null) {
				String number=textField.getText()+bSix.getText();
				textField.setText(number);
				a=Double.parseDouble(number);
			}
		
		
		}
		});
		JButton bOne = new JButton("1");
		bOne.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bOne.setBounds(21, 176, 50, 31);
		frame.getContentPane().add(bOne);
		bOne.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bOne.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bOne.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bOne.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bOne.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			});
		
		JButton bTwo = new JButton("2");
		bTwo.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bTwo.setBounds(78, 176, 50, 31);
		frame.getContentPane().add(bTwo);
		bTwo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bTwo.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bTwo.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bTwo.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bTwo.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			
			}
			});
		
		JButton bThree = new JButton("3");
		bThree.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bThree.setBounds(132, 176, 50, 31);
		frame.getContentPane().add(bThree);
		bThree.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bThree.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bThree.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bThree.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bThree.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			}
			});
		
		JButton bZero = new JButton("0");
		bZero.setFont(new Font("Tahoma", Font.PLAIN, 10));
		bZero.setBounds(21, 218, 50, 31);
		frame.getContentPane().add(bZero);
		bZero.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(operacion!=null) {
					String number=textField.getText()+bZero.getText();
					textField.setText(number);
					b=Double.parseDouble(number);
				}if(haceOperacion){
					if(textField.getText().contains("-") && c>0) {
						String number=textField.getText()+bZero.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}else {
						textField.setText(null);
						String number=textField.getText()+bZero.getText();
						textField.setText(number);
						a=Double.parseDouble(number);
						haceOperacion=false;
					}	
				
				}else if(operacion==null) {
					String number=textField.getText()+bZero.getText();
					textField.setText(number);
					a=Double.parseDouble(number);
				}
			
			
				
			}
			});
		
		JButton bAdd = new JButton("+");
		bAdd.setFont(new Font("Tahoma", Font.PLAIN, 5));
		bAdd.setBounds(192, 45, 50, 31);
		frame.getContentPane().add(bAdd);
		bAdd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				operacion="+";
			}
			});
		
		
		JButton bMinus = new JButton("-");
		bMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(textField.getText().length()>0 && !haceOperacion) {
					textField.setText(null);
					operacion="-";
				}else{
					textField.setText(bMinus.getText());
					
					
				}
				
				
			}
		});
		bMinus.setBounds(192, 88, 50, 31);
		frame.getContentPane().add(bMinus);
		
		
		JButton bDiv = new JButton("/");
		bDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				operacion="/";
				
			}
		});
		bDiv.setBounds(192, 134, 49, 31);
		frame.getContentPane().add(bDiv);
		
		
		JButton bMult = new JButton("*");
		bMult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				operacion="*";
			}
		});
		bMult.setFont(new Font("Tahoma", Font.PLAIN, 8));
		bMult.setBounds(193, 177, 49, 31);
		frame.getContentPane().add(bMult);
				
		
		JButton bFact = new JButton("%");
		bFact.setBounds(132, 218, 50, 31);
		frame.getContentPane().add(bFact);
		bFact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 c= 1;
				 if (a <= 0) {
					 JOptionPane.showMessageDialog(null, "No puede hacerse el factorial de negativos", "ERROR", JOptionPane.WARNING_MESSAGE);
					 throw new RuntimeException();
					}
				 
				 if (a >= 13) {
					 JOptionPane.showMessageDialog(null, "N�mero muy grande", "ERROR", JOptionPane.WARNING_MESSAGE);
					 throw new RuntimeException();
					
				 }else {
				      for( int i = 1; i <= a; i++ ) {
				    	  c*= i;
				      }
				 }
				 textField.setText(String.valueOf(c));
				 a=0;
				 b=0;
				 operacion=null;
				 haceOperacion=true;
				
			}
		});
		
		JButton bEqual = new JButton("=");
		bEqual.setBounds(21, 259, 223, 31);
		frame.getContentPane().add(bEqual);
		bEqual.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
			try {
				if(operacion.equals("+")) {
					c=a+b;
					textField.setText(String.valueOf(c));
				}if(operacion.equals("-")) {
					c=a-b;
					textField.setText(String.valueOf(c));
				}if(operacion.equals("/")) {
					
					if(b==0) {
						JOptionPane.showMessageDialog(null, "No puede dividirse por 0", "ERROR", JOptionPane.WARNING_MESSAGE);
						throw new ArithmeticException();
					}
					c = a/b;
					textField.setText(String.valueOf(c));
				}if(operacion.equals("*")) {
					c=a*b;
					textField.setText(String.valueOf(c));
				
			    }
				operacion=null;
				a=0;
				b=0;
				haceOperacion=true;
				
			}catch(NullPointerException n) {
				textField.setText(null);
				JOptionPane.showMessageDialog(null, "No ha seleccionado ninguna operaci�n", "ERROR", JOptionPane.WARNING_MESSAGE);
				throw new NullPointerException();
				
			}
				
				
			}
			});
		
		JButton bDel = new JButton("C");
		bDel.setBounds(78, 45, 50, 31);
		frame.getContentPane().add(bDel);
		bDel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
				a=0;
				b=0;
				c=0;
				haceOperacion=false;
				
				
			}
			});

		
		JButton bPrime = new JButton("=");
		bPrime.setBounds(192, 218, 50, 31);
		frame.getContentPane().add(bPrime);
		bPrime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(b!=0) {
					a=b;
				}
				
				int i = 2;
				  c=2;
				  while ((c==2) && (i!=(int)a)){
				    if ((int)a % i == 0)
				      c = 1;
				    i++;
				  }if (c==2) {
					  textField.setText("True");
				  }else {
					  textField.setText("False");
				  }
				  a=0;
				  b=0;
				  operacion=null;
				  haceOperacion=true;
			}
		});
		
		JButton bBack = new JButton("<-");
		bBack.setBounds(21, 45, 50, 31);
		frame.getContentPane().add(bBack);
		bBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String backSpace=null;
				if(textField.getText().length()>0) {
					StringBuilder str = new StringBuilder(textField.getText());
					str.deleteCharAt(textField.getText().length()-1);
					backSpace=str.toString();
					textField.setText(backSpace);

					if(operacion!=null) {
						b=Double.parseDouble(backSpace);
					}else {
						a=Double.parseDouble(backSpace);
					}
			}
				}
		});
		
		JButton b00 = new JButton("00");
		b00.setBounds(132, 45, 50, 31);
		frame.getContentPane().add(b00);
		b00.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+b00.getText();
				textField.setText(number);
				if(operacion!=null) {
					b=Double.parseDouble(number);
				}else {
					a=Double.parseDouble(number);
				}
			}
		});
		
		JButton bPoint = new JButton(".");
		bPoint.setBounds(78, 218, 50, 31);
		frame.getContentPane().add(bPoint);
		bPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+bPoint.getText();
				textField.setText(number);
			}
		});
	}
}

